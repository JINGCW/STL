#ifndef LUTOK2_COMMON_H
#define LUTOK2_COMMON_H

#include <lua.hpp>
#include <cassert>
#include <string>
#include <exception>
#include <unordered_map>
#include <vector>
#include <utility>
#include <functional>
#include <tuple>
#include <type_traits>
#include <typeinfo>

#endif